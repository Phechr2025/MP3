from flask import Flask, render_template, request, redirect, url_for, send_file, jsonify
import yt_dlp
import os
import datetime

app = Flask(__name__)
DOWNLOAD_FOLDER = "downloads"
HISTORY_FILE = "history.txt"
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

# โหลดประวัติ
def load_history():
    if not os.path.exists(HISTORY_FILE):
        return []
    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        return [line.strip().split("|") for line in f.readlines()]

# บันทึกประวัติ
def save_history(data):
    with open(HISTORY_FILE, "a", encoding="utf-8") as f:
        f.write("|".join(data) + "\n")

# ล้างประวัติ
@app.route("/clear_history")
def clear_history():
    open(HISTORY_FILE, "w").close()
    return redirect(url_for("admin"))

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        url = request.form["url"]
        fmt = request.form["format"]
        custom_name = request.form["name"].strip()

        # ตรวจสอบว่าเป็นวิดีโอเดี่ยว ไม่ใช่เพลย์ลิสต์
        if "playlist" in url or "list=" in url:
            return render_template("index.html", error="กรุณาเลือกวิดีโอเดี่ยว ไม่รองรับเพลย์ลิสต์")

        # ตั้งชื่อไฟล์
        ts = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S")
        filename = f"{custom_name if custom_name else ts}.{fmt}"
        filepath = os.path.join(DOWNLOAD_FOLDER, filename)

        # ดึงข้อมูล metadata
        ydl_opts = {"quiet": True, "skip_download": True}
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            thumbnail = info.get("thumbnail")

        # ดาวน์โหลดไฟล์จริง
        ydl_opts = {
            "outtmpl": filepath,
            "format": "bestaudio/best" if fmt == "mp3" else "bestvideo+bestaudio/best",
            "postprocessors": [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3"}] if fmt == "mp3" else []
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])

        # บันทึกประวัติ (เวลา, รูปแบบ, ชื่อ, ไฟล์, ลิ้งค์, thumbnail)
        save_history([datetime.datetime.utcnow().isoformat(), fmt, custom_name or "No Name", filename, url, thumbnail])

        return send_file(filepath, as_attachment=True)

    return render_template("index.html", error=None)

@app.route("/admin")
def admin():
    history = load_history()
    return render_template("admin.html", history=history)
