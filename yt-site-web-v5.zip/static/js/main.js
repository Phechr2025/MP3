\
const urlEl = document.getElementById('url');
const fmtEl = document.getElementById('format');
const startBtn = document.getElementById('startBtn');
const progressBox = document.getElementById('progressBox');
const bar = document.getElementById('bar');
const pct = document.getElementById('pct');
const result = document.getElementById('result');
const thumbBox = document.getElementById('thumbBox');
const thumbImg = document.getElementById('thumbImg');

function isLikelySingleVideo(u){
  if(!u) return false;
  if(!/^https?:\/\//.test(u)) return false;
  return !(u.includes('list=') || u.toLowerCase().includes('playlist'));
}

startBtn?.addEventListener('click', async ()=>{
  const url = (urlEl.value || '').trim();
  const fmt = (fmtEl.value || 'mp3').trim();

  // Hide progress until validated
  progressBox.classList.add('hidden');
  result.innerHTML = '';
  thumbBox.classList.add('hidden');

  if(!isLikelySingleVideo(url)){
    result.innerHTML = '<span style="color:#ff9e9e">ต้องเป็นวิดีโอเดี่ยว และลิงก์ต้องขึ้นด้วย http/https</span>';
    return;
  }

  startBtn.disabled = true;
  startBtn.classList.add('pulse');
  startBtn.textContent = 'กำลังเริ่ม...';

  try{
    const form = new FormData();
    form.append('url', url);
    form.append('format', fmt);
    const resp = await fetch('/start', {method:'POST', body:form});
    const data = await resp.json();
    if(!data.ok){
      throw new Error(data.error || 'เริ่มงานไม่สำเร็จ');
    }
    const job = data.job_id;

    // show progress now
    progressBox.classList.remove('hidden');
    bar.style.width = '0%'; pct.textContent = '0%';
    result.innerHTML = '';

    // poll progress
    const timer = setInterval(async ()=>{
      const r = await fetch('/progress/'+job);
      const j = await r.json();
      if(!j.ok){ clearInterval(timer); result.innerHTML = 'เกิดข้อผิดพลาด'; return; }

      if(j.thumb){
        thumbBox.classList.remove('hidden');
        thumbImg.src = j.thumb;
      }

      if(j.status === 'downloading' || j.status === 'processing'){
        const p = j.progress ?? 0;
        bar.style.width = p + '%';
        pct.textContent = p + '%';
      }
      if(j.status === 'done'){
        clearInterval(timer);
        bar.style.width = '100%'; pct.textContent = '100%';
        result.innerHTML = `<a class="btn-primary" href="/download/${encodeURIComponent(j.filename)}">ดาวน์โหลดไฟล์ (${j.filename})</a>`;
        startBtn.disabled = false;
        startBtn.classList.remove('pulse');
        startBtn.textContent = 'เริ่มดาวน์โหลด';
      }
      if(j.status === 'error'){
        clearInterval(timer);
        result.innerHTML = `<span style="color:#ff9e9e">${j.error}</span>`;
        startBtn.disabled = false;
        startBtn.classList.remove('pulse');
        startBtn.textContent = 'เริ่มดาวน์โหลด';
      }
    }, 900);
  }catch(err){
    result.innerHTML = `<span style="color:#ff9e9e">${err.message}</span>`;
    startBtn.disabled = false;
    startBtn.classList.remove('pulse');
    startBtn.textContent = 'เริ่มดาวน์โหลด';
  }
});

// subtle button animation
document.querySelectorAll('.btn,.btn-primary').forEach(b=>{
  b.addEventListener('mousedown',()=> b.style.transform='scale(.98)');
  b.addEventListener('mouseup',()=> b.style.transform='');
  b.addEventListener('mouseleave',()=> b.style.transform='');
});
