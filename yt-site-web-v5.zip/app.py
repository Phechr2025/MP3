\
import os, re, uuid, json, threading, time, shutil, tempfile
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, session, flash
from dotenv import load_dotenv
from yt_dlp import YoutubeDL

load_dotenv()
APP_PORT = int(os.getenv("APP_PORT","8090"))
APP_HOST = os.getenv("APP_HOST","0.0.0.0")
SECRET_KEY = os.getenv("SECRET_KEY","change-me")
PANEL_USER = os.getenv("PANEL_USER","admin")
PANEL_PASS = os.getenv("PANEL_PASS","1234")

app = Flask(__name__)
app.secret_key = SECRET_KEY

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
DL_DIR = os.path.join(BASE_DIR, "downloads")
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(DL_DIR, exist_ok=True)

HISTORY_PATH = os.path.join(DATA_DIR, "history.json")
CONFIG_PATH = os.path.join(DATA_DIR, "config.json")

# In-memory progress store
PROGRESS = {}  # job_id -> dict(progress, status, filename, thumb, error)

# Helpers
def _read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def _write_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def is_single_video(url: str) -> bool:
    if not url or not re.match(r"^https?://", url.strip()):
        return False
    # heuristic reject if playlist param present
    if "list=" in url or "playlist" in url:
        return False
    return True

def _yt_thumb_from_info(info):
    # Try highest resolution thumbnail
    thumb = info.get("thumbnail")
    if not thumb:
        # Some formats store thumbnails under "thumbnails"
        thumbs = info.get("thumbnails") or []
        if thumbs:
            thumb = sorted(thumbs, key=lambda t: t.get("height",0), reverse=True)[0].get("url")
    return thumb

def _background_download(job_id, url, fmt):
    PROGRESS[job_id] = {"progress": 0, "status":"starting", "filename": None, "thumb": None, "error": None}
    tmpdir = tempfile.mkdtemp(prefix="dl_")
    try:
        # probe metadata first (also confirms it's a single video to backend)
        ydl_probe = YoutubeDL({"quiet": True, "skip_download": True})
        info = ydl_probe.extract_info(url, download=False)
        if "entries" in info:
            raise Exception("ลิงก์นี้เป็นเพลย์ลิสต์ กรุณาใช้วิดีโอเดี่ยวเท่านั้น")

        title = info.get("title") or "video"
        thumb_url = _yt_thumb_from_info(info)
        PROGRESS[job_id]["thumb"] = thumb_url

        # Build ydl options
        outtmpl = os.path.join(tmpdir, "%(title)s.%(ext)s")
        postprocessors = []
        if fmt == "mp3":
            postprocessors = [
                {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"},
                {"key": "EmbedThumbnail"},
                {"key": "FFmpegMetadata"},
            ]
            ydl_opts = {
                "format": "bestaudio/best",
                "outtmpl": outtmpl,
                "writethumbnail": True,
                "postprocessors": postprocessors,
                "noplaylist": True,
                "quiet": True,
                "progress_hooks": [lambda d: _hook(job_id, d)],
            }
        else:  # mp4
            # best mp4 if possible, else bestvideo+bestaudio merged
            ydl_opts = {
                "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
                "outtmpl": outtmpl,
                "writethumbnail": True,
                "postprocessors": [
                    {"key": "FFmpegVideoRemuxer", "preferedformat": "mp4"},
                    {"key": "EmbedThumbnail"},
                    {"key": "FFmpegMetadata"},
                ],
                "noplaylist": True,
                "quiet": True,
                "progress_hooks": [lambda d: _hook(job_id, d)],
            }

        with YoutubeDL(ydl_opts) as ydl:
            result = ydl.download([url])

        # Find produced file
        produced = None
        for name in os.listdir(tmpdir):
            if name.lower().endswith(f".{fmt}"):
                produced = os.path.join(tmpdir, name)
                break
        if not produced:
            # fallback: find largest file
            files = [os.path.join(tmpdir, n) for n in os.listdir(tmpdir)]
            if not files:
                raise Exception("ไม่พบไฟล์ที่ดาวน์โหลด")
            produced = max(files, key=os.path.getsize)

        # Move to DL_DIR
        safe_name = re.sub(r'[\\/*?:"<>|]+','_', os.path.basename(produced))
        final_path = os.path.join(DL_DIR, safe_name)
        shutil.move(produced, final_path)
        PROGRESS[job_id]["status"] = "done"
        PROGRESS[job_id]["filename"] = os.path.basename(final_path)

        # Save history
        hist = _read_json(HISTORY_PATH, [])
        hist.append({
            "id": job_id,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "title": title,
            "format": fmt,
            "source_url": url,
            "file_url": f"/download/{os.path.basename(final_path)}",
        })
        _write_json(HISTORY_PATH, hist)

    except Exception as e:
        PROGRESS[job_id]["status"] = "error"
        PROGRESS[job_id]["error"] = str(e)
    finally:
        # cleanup temp
        try:
            shutil.rmtree(tmpdir, ignore_errors=True)
        except Exception:
            pass

def _hook(job_id, d):
    if d.get("status") == "downloading":
        total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
        downloaded = d.get("downloaded_bytes") or 0
        pct = 0
        if total:
            pct = int(downloaded * 100 / total)
        PROGRESS[job_id].update({"progress": pct, "status": "downloading"})
    elif d.get("status") == "finished":
        PROGRESS[job_id].update({"progress": 100, "status": "processing"})

@app.route("/")
def index():
    cfg = _read_json(CONFIG_PATH, {"announcement":"", "download_enabled": True})
    return render_template("index.html",
                           announcement=cfg.get("announcement",""),
                           download_enabled=cfg.get("download_enabled", True))

@app.route("/start", methods=["POST"])
def start_download():
    cfg = _read_json(CONFIG_PATH, {"announcement":"", "download_enabled": True})
    if not cfg.get("download_enabled", True):
        return jsonify({"ok": False, "error": "ปิดการดาวน์โหลดชั่วคราวโดยผู้ดูแล"}), 403

    url = (request.form.get("url") or "").strip()
    fmt = (request.form.get("format") or "mp3").strip().lower()

    if fmt not in ("mp3","mp4"):
        return jsonify({"ok": False, "error": "รูปแบบไม่ถูกต้อง"}), 400

    if not is_single_video(url):
        return jsonify({"ok": False, "error": "ต้องเป็นวิดีโอเดี่ยวจาก YouTube (ไม่ใช่เพลย์ลิสต์) และลิงก์ต้องขึ้นต้นด้วย http/https"}), 400

    job_id = uuid.uuid4().hex[:12]
    t = threading.Thread(target=_background_download, args=(job_id, url, fmt), daemon=True)
    t.start()
    return jsonify({"ok": True, "job_id": job_id})

@app.route("/progress/<job_id>")
def progress(job_id):
    data = PROGRESS.get(job_id)
    if not data:
        return jsonify({"ok": False, "error": "ไม่พบงานนี้"}), 404
    return jsonify({"ok": True, **data})

@app.route("/download/<path:fname>")
def download_file(fname):
    path = os.path.join(DL_DIR, fname)
    if not os.path.isfile(path):
        return "Not found", 404
    return send_file(path, as_attachment=True, download_name=fname)

# -------- Admin --------
def require_login():
    return session.get("logged_in") is True

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username","")
        p = request.form.get("password","")
        if u == PANEL_USER and p == PANEL_PASS:
            session["logged_in"] = True
            return redirect(url_for("admin"))
        flash("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง")
    return render_template("admin_login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/admin")
def admin():
    if not require_login():
        return redirect(url_for("login"))
    cfg = _read_json(CONFIG_PATH, {"announcement":"", "download_enabled": True})
    hist = list(reversed(_read_json(HISTORY_PATH, [])))  # newest first
    return render_template("admin.html", cfg=cfg, history=hist)

@app.post("/admin/toggle")
def admin_toggle():
    if not require_login():
        return "Unauthorized", 401
    cfg = _read_json(CONFIG_PATH, {"announcement":"", "download_enabled": True})
    cfg["download_enabled"] = not cfg.get("download_enabled", True)
    _write_json(CONFIG_PATH, cfg)
    return redirect(url_for("admin"))

@app.post("/admin/announce")
def admin_announce():
    if not require_login():
        return "Unauthorized", 401
    text = (request.form.get("announcement") or "").strip()
    cfg = _read_json(CONFIG_PATH, {"announcement":"", "download_enabled": True})
    cfg["announcement"] = text
    _write_json(CONFIG_PATH, cfg)
    return redirect(url_for("admin"))

@app.post("/admin/clear_history")
def admin_clear_history():
    if not require_login():
        return "Unauthorized", 401
    _write_json(HISTORY_PATH, [])
    return redirect(url_for("admin"))

@app.after_request
def add_headers(resp):
    resp.headers['Cache-Control'] = 'no-store'
    return resp

if __name__ == "__main__":
    app.run(host=APP_HOST, port=APP_PORT)
