
import os
import uuid
import json
import threading
import time
from datetime import datetime, time as dtime, timedelta
from zoneinfo import ZoneInfo

from flask import Flask, render_template, request, jsonify, send_from_directory, redirect, url_for
from werkzeug.utils import secure_filename

from yt_dlp import YoutubeDL

# ------------ Config -------------
APP_VERSION = "v3"
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
DL_DIR = os.path.join(DATA_DIR, "downloads")
HISTORY_FILE = os.path.join(DATA_DIR, "history.json")
CONFIG_FILE = os.path.join(DATA_DIR, "config.json")

os.makedirs(DL_DIR, exist_ok=True)

DEFAULT_CONFIG = {
    "download_enabled": True,
    "announcement": "",
    "schedule": { "enabled": False, "start": "00:00", "end": "23:59", "tz": "Asia/Bangkok" }
}

# In-memory progress store
PROGRESS = {}
LOCK = threading.Lock()

def load_json(path, default):
    if not os.path.exists(path):
        save_json(path, default)
        return default
    with open(path, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except Exception:
            return default

def save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

CONFIG = load_json(CONFIG_FILE, DEFAULT_CONFIG)
HISTORY = load_json(HISTORY_FILE, [])

def thai_now():
    return datetime.now(ZoneInfo(CONFIG.get("schedule", {}).get("tz", "Asia/Bangkok")))

def schedule_allows_now():
    sched = CONFIG.get("schedule", {})
    if not sched.get("enabled", False):
        return True
    tz = ZoneInfo(sched.get("tz", "Asia/Bangkok"))
    now = datetime.now(tz).time()
    start_h, start_m = map(int, sched.get("start", "00:00").split(":"))
    end_h, end_m = map(int, sched.get("end", "23:59").split(":"))
    start_t = dtime(hour=start_h, minute=start_m)
    end_t = dtime(hour=end_h, minute=end_m)
    if start_t <= end_t:
        return start_t <= now <= end_t
    # Overnight window (e.g., 22:00-06:00)
    return now >= start_t or now <= end_t

# --------- Helpers ----------
def is_single_video(url: str) -> bool:
    # Detect playlist-ish quickly
    lowered = url.lower()
    bad_params = ["list=", "playlist?"]
    if any(p in lowered for p in bad_params):
        return False
    # Ask yt-dlp without downloading
    ydl_opts = {"quiet": True, "skip_download": True}
    with YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=False)
    # If extractor returns playlist with 'entries', reject
    if info.get("_type") == "playlist" or "entries" in info:
        return False
    return True

def build_filename(title, ext, custom_name=None):
    base = custom_name.strip() if custom_name else title
    safe = secure_filename(base)[:120] or "video"
    return f"{safe}.{ext}"

def progress_hook(job_id):
    def hook(d):
        with LOCK:
            entry = PROGRESS.setdefault(job_id, {})
            if d['status'] == 'downloading':
                entry['status'] = 'downloading'
                entry['downloaded_bytes'] = d.get('downloaded_bytes', 0)
                entry['total_bytes'] = d.get('total_bytes') or d.get('total_bytes_estimate', 0)
                entry['speed'] = d.get('speed', 0)
                entry['eta'] = d.get('eta', 0)
                entry['percent'] = round(100 * entry['downloaded_bytes'] / entry['total_bytes'], 1) if entry['total_bytes'] else 0.0
            elif d['status'] == 'finished':
                entry['status'] = 'processing'
            PROGRESS[job_id] = entry
    return hook

def do_download(job_id, url, fmt, custom_name):
    thumb_url = None
    result = {"ok": False, "file_url": "", "thumb": ""}
    try:
        # Probe info first
        with YoutubeDL({"quiet": True}) as y:
            info = y.extract_info(url, download=False)
            title = info.get("title", "video")
            thumb_url = info.get("thumbnail")

        outtmpl = os.path.join(DL_DIR, "%(title).200s.%(ext)s")
        # Prepare options
        if fmt == "mp3":
            ydl_opts = {
                "format": "bestaudio/best",
                "outtmpl": outtmpl,
                "noplaylist": True,
                "writethumbnail": True,
                "postprocessors": [
                    {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"},
                    {"key": "FFmpegThumbnailsConvertor", "format": "jpg"},
                    {"key": "EmbedThumbnail"}
                ],
                "progress_hooks": [progress_hook(job_id)],
                "quiet": True,
            }
            out_ext = "mp3"
        else:  # mp4
            ydl_opts = {
                "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
                "outtmpl": outtmpl,
                "noplaylist": True,
                "writethumbnail": True,
                "postprocessors": [
                    # For mp4 embedding thumbnail yt-dlp uses AtomicParsley if present; we attempt anyway
                    {"key": "EmbedThumbnail", "already_have_thumbnail": False}
                ],
                "progress_hooks": [progress_hook(job_id)],
                "quiet": True,
            }
            out_ext = "mp4"

        with YoutubeDL(ydl_opts) as y:
            info = y.extract_info(url, download=True)
            title = info.get("title","video")
            # Find resulting file
            # yt-dlp returns filename via prepare_filename BEFORE pp; try both ext
            base_name = os.path.splitext(y.prepare_filename(info))[0]
            # After postprocessing, extension changes possibly
            candidate = base_name + f".{out_ext}"
            if not os.path.exists(candidate):
                # Fallback: scan DL_DIR for latest matching
                files = sorted([p for p in os.listdir(DL_DIR) if p.endswith(out_ext)], key=lambda p: os.path.getmtime(os.path.join(DL_DIR,p)), reverse=True)
                candidate = os.path.join(DL_DIR, files[0]) if files else ""
            else:
                candidate = candidate

        if not candidate or not os.path.exists(candidate):
            raise RuntimeError("ไม่พบไฟล์ผลลัพธ์หลังดาวน์โหลด")

        # If custom name provided, rename
        dest = os.path.join(DL_DIR, build_filename(title, out_ext, custom_name))
        if os.path.abspath(candidate) != os.path.abspath(dest):
            try:
                os.replace(candidate, dest)
            except Exception:
                dest = candidate  # fallback

        # Save history item
        item = {
            "ts": datetime.utcnow().isoformat()+"Z",
            "format": fmt,
            "title": title,
            "filename": os.path.basename(dest)
        }
        HISTORY.insert(0, item)
        save_json(HISTORY_FILE, HISTORY[:500])  # cap

        result["ok"] = True
        result["file_url"] = "/file/" + os.path.basename(dest)
        result["thumb"] = thumb_url or ""
    except Exception as e:
        with LOCK:
            PROGRESS[job_id] = {"status": "error", "error": str(e)}
        result = {"ok": False, "error": str(e), "thumb": thumb_url or ""}
    finally:
        with LOCK:
            PROGRESS.setdefault(job_id, {}).setdefault("done", True)
            PROGRESS[job_id]["result"] = result

# ------------- Flask app --------------
app = Flask(__name__, static_folder="static", template_folder="templates")

@app.route("/")
def index():
    ann = CONFIG.get("announcement","").strip()
    return render_template("index.html", version=APP_VERSION, enabled=CONFIG.get("download_enabled", True),
                           announcement=ann)

@app.route("/admin", methods=["GET","POST"])
def admin():
    if request.method == "POST":
        # very lightweight auth using .env style vars set via config.json (no sensitive data here)
        action = request.form.get("action")
        if action == "toggle":
            CONFIG["download_enabled"] = (request.form.get("enabled") == "true")
            save_json(CONFIG_FILE, CONFIG)
        elif action == "clear_history":
            HISTORY.clear()
            save_json(HISTORY_FILE, HISTORY)
        elif action == "save_schedule":
            CONFIG["schedule"] = {
                "enabled": request.form.get("sched_enabled") == "true",
                "start": request.form.get("start") or "00:00",
                "end": request.form.get("end") or "23:59",
                "tz": request.form.get("tz") or "Asia/Bangkok"
            }
            save_json(CONFIG_FILE, CONFIG)
        elif action == "save_announcement":
            CONFIG["announcement"] = request.form.get("announcement","")
            save_json(CONFIG_FILE, CONFIG)
        return redirect(url_for("admin"))
    return render_template("admin.html", version=APP_VERSION, enabled=CONFIG.get("download_enabled", True),
                           schedule=CONFIG.get("schedule", DEFAULT_CONFIG["schedule"]),
                           history=HISTORY, announcement=CONFIG.get("announcement",""))

@app.post("/start_job")
def start_job():
    if not CONFIG.get("download_enabled", True) or not schedule_allows_now():
        return jsonify({"ok": False, "error": "ระบบปิดรับดาวน์โหลดชั่วคราว"}), 403
    url = (request.form.get("url") or "").strip()
    fmt = request.form.get("format") or "mp3"
    custom = (request.form.get("name") or "").strip()

    if not url:
        return jsonify({"ok": False, "error": "กรุณาใส่ลิงก์"}), 400

    try:
        if not is_single_video(url):
            return jsonify({"ok": False, "error": "ลิงก์นี้เป็นเพลย์ลิสต์ กรุณาใช้ลิงก์วิดีโอเดี่ยว"}), 400
    except Exception as e:
        return jsonify({"ok": False, "error": f"ตรวจสอบลิงก์ไม่สำเร็จ: {e}"}), 400

    job_id = uuid.uuid4().hex[:12]
    with LOCK:
        PROGRESS[job_id] = {"status":"queued","percent":0.0}

    t = threading.Thread(target=do_download, args=(job_id, url, fmt, custom), daemon=True)
    t.start()

    return jsonify({"ok": True, "job_id": job_id})

@app.get("/progress/<job_id>")
def progress(job_id):
    with LOCK:
        data = PROGRESS.get(job_id, {"status":"unknown"})
    return jsonify(data)

@app.get("/file/<path:filename>")
def files(filename):
    return send_from_directory(DL_DIR, filename, as_attachment=True)

@app.get("/health")
def health():
    return {"ok": True, "time": datetime.utcnow().isoformat()+"Z"}

if __name__ == "__main__":
    # Dev run
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8090")))
