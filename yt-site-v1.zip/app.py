from flask import Flask, render_template, request, redirect, url_for, session, flash
import yt_dlp
import os

app = Flask(__name__)
app.secret_key = "supersecretkey"

# Home page
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        url = request.form["url"]
        filetype = request.form["filetype"]
        ydl_opts = {
            "format": "bestaudio/best" if filetype == "mp3" else "best",
            "outtmpl": "downloads/%(title)s.%(ext)s"
        }
        os.makedirs("downloads", exist_ok=True)
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            filename = ydl.prepare_filename(info)
        flash(f"ดาวน์โหลดเสร็จสิ้น: {os.path.basename(filename)}")
        return redirect(url_for("index"))
    return render_template("index.html")

# Admin login
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = request.form["username"]
        pw = request.form["password"]
        if user == os.getenv("PANEL_USER", "admin") and pw == os.getenv("PANEL_PASS", "1234"):
            session["admin"] = True
            return redirect(url_for("admin"))
        flash("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง")
    return render_template("login.html")

@app.route("/admin")
def admin():
    if not session.get("admin"):
        return redirect(url_for("login"))
    return render_template("admin.html")

@app.route("/logout")
def logout():
    session.pop("admin", None)
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8090)
